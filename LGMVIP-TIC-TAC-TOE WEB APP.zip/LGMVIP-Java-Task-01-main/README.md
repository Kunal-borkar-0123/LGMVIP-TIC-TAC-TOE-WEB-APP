# LGMVIP-Java-Task-01
----
GUI-based Tic-Tac-Toe Game using Java, Java Swing, and JFrame.
----
Project Overview: This is a GUI-based Tic-Tac-Toe Game. It is executable on a desktop environment. It is developed in JAVA, using Java Swing and JFrame for GUI design.

IDE used: Eclipse

Tech Stack: Java, Java Swing, JFrame
